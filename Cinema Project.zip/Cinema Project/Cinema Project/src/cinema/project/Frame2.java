package cinema.project;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class Frame2 extends javax.swing.JFrame {

    Connection sos = null;
    PreparedStatement sss = null;
    ResultSet rs = null;

    private JComboBox<String> screenDropdown;
    private JComboBox<String> cityDropdown;
    private JComboBox<String> seatDropdown;
    private JComboBox<String> dateDropdown;
    private JComboBox<String> timeDropdown;
    private int totalSeats;

    private void initComponents2() {
        setMinimumSize(new Dimension(400, 300));

        // Fetch movie count from the database
        int movieCount = getMovieCount();
        if (movieCount == 0) {
            // Handle the case where there are no movies
            return;
        }

        // Fetch total seats for the first movie (you can modify this based on your logic)
        totalSeats = 60; // getTotalSeatsForMovie(27); // Assuming Movie_iD starts from 1
        
        // Create a dropdown list with seat numbers
        List<String> seatNumbers = generateSeatNumbers(totalSeats);
        seatDropdown = new JComboBox<>(seatNumbers.toArray(new String[0]));

        // Dropdown for selecting screens (1 to 5)
        String[] screenOptions = {"1", "2", "3", "4", "5"};
        screenDropdown = new JComboBox<>(screenOptions);

        // Dropdown for selecting cities
        String[] cityOptions = {"Islamabad", "Karachi", "Lahore"};
        cityDropdown = new JComboBox<>(cityOptions);

        JPanel seatPanel = new JPanel();
        seatPanel.setBackground(Color.CYAN);
        seatPanel.add(new JLabel("Select Seats:"));
        seatPanel.add(seatDropdown);
        seatPanel.add(new JLabel("Select Screen:"));
        seatPanel.add(screenDropdown);
        seatPanel.add(new JLabel("Select City:"));
        seatPanel.add(cityDropdown);

        JButton proceedButton = new JButton("Proceed");
        proceedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle the "Proceed" button click
                handleProceedButtonClick();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.CYAN);
        buttonPanel.add(proceedButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(seatPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        pack();

        JPanel permanentLabelsPanel = new JPanel(new GridLayout(1, 3));
        permanentLabelsPanel.setBackground(Color.CYAN);

        // Create labels for seat categories
        JLabel silverLabel = new JLabel("1-20   Silver");
        JLabel goldLabel = new JLabel("21-40  Gold");
        JLabel premiumLabel = new JLabel("41-60  Premium");

        // Add labels to the panel
        permanentLabelsPanel.add(silverLabel);
        permanentLabelsPanel.add(goldLabel);
        permanentLabelsPanel.add(premiumLabel);

        // Set the preferred size to make it square (adjust the values as needed)
        Dimension preferredSize = new Dimension(375, 30); // Adjust the height as needed
        permanentLabelsPanel.setPreferredSize(preferredSize);

        // Create a panel for labels and "Proceed" button
        JPanel bottomLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomLeftPanel.add(permanentLabelsPanel);

        // Add the panel to the bottom left of the main frame
        getContentPane().add(bottomLeftPanel, BorderLayout.BEFORE_FIRST_LINE);
    }

    private void handleProceedButtonClick() {
    // Get the selected seat details from the dropdown list
    String selectedSeat = (String) seatDropdown.getSelectedItem();
    // Extract seat category and display the corresponding price
    int noseat = Integer.parseInt(selectedSeat);
    String seatCategory = getSeatCategory(noseat);
    // Get the selected screen from the dropdown
    String selectedScreen = (String) screenDropdown.getSelectedItem();

    // Get the selected city from the dropdown
    String selectedCity = (String) cityDropdown.getSelectedItem();
    String timey = (String) timeDropdown.getSelectedItem();
    String datey = (String) dateDropdown.getSelectedItem();
    String showid = " ";
    try
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
            String sql1 = "SELECT Show_iD FROM screen WHERE Movie_iD = ? AND Location = ? And Screen_iD = ? And Date = ? And Time = ?";
                 PreparedStatement pst1 = con.prepareStatement(sql1);
                 pst1.setInt(1,this.movieID);
                 pst1.setString(2,selectedCity);
                 pst1.setString(3,(String) screenDropdown.getSelectedItem());
                 pst1.setString(4,datey);
                 pst1.setString(5,timey);
                 ResultSet rs1 = pst1.executeQuery();
                 rs1.next();
                 showid = rs1.getString(1);
        }
    catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error!");
        }
    int seatPrice = getSeatPrice(seatCategory);
    String message = "Selected Seat: " + selectedSeat + "\nSeat Category: " + seatCategory +
            "\nPrice: " + seatPrice + "\nSelected Screen: " + selectedScreen + "\nSelected City: " + selectedCity + "\nSelected seat: " + selectedSeat +"\nSelected time: " + timey + "\nSelected date: " +  datey;

    // Display the message
    JOptionPane.showMessageDialog(this, message);

    // Create an instance of Frame1 and pass the information to its overloaded constructor
    this.dispose();
    Frame1 frame1 = new Frame1(userID,movieID, movieName, selectedScreen, selectedCity, seatPrice, seatCategory,showid,selectedSeat);

    // Make Frame1 visible
    frame1.setVisible(true);
}


    private String getSeatCategory(int seatNumber) {
        if (seatNumber >= 1 && seatNumber <= 15) {
            return "Premium";
        } else if (seatNumber >= 16 && seatNumber <= 45) {
            return "Gold";
        } else {
            return "Silver";
        }
    }

    private int getSeatPrice(String seatCategory) {
        switch (seatCategory) {
            case "Silver":
                return 1000;
            case "Gold":
                return 2000;
            case "Premium":
                return 3500;
            default:
                return 0; // Handle unknown category
        }
    }

    private int getMovieCount() {
        try
        {

            Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
            String countSql = "SELECT COUNT(*) FROM movieadmin";
            sss = con.prepareStatement(countSql);
            rs = sss.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
         catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Error!");
        }
        return 0;
    }

    private List<String> generateSeatNumbers(int totalSeats) {
        List<String> seatNumbers = new ArrayList<>();
        for (int i = 1; i <= totalSeats; i++) {
            seatNumbers.add("Seat " + i);
        }
        return seatNumbers;
    }

    /**
     * Creates new form Frame2
     */
    public Frame2() {
        
        System.out.println("Received Movie ID: " + movieID);
    System.out.println("Received Movie Name: " + movieName);
    System.out.println("Received Showtimes: " + showtimes);
        initComponents2();
    }
 // Additional fields to store movie information
    private int userID;
    private int movieID;
    private String movieName;
    private String showtimes;
 // Overloaded constructor to receive movie information
   
    public Frame2(int userID,int movieID, String movieName, String showtimes) {
        
        
        System.out.println("Received Movie ID: " + movieID);
    System.out.println("Received Movie Name: " + movieName);
    System.out.println("Received Showtimes: " + showtimes);
        this.userID = userID;
        this.movieID = movieID;
        this.movieName = movieName;
        this.showtimes = showtimes;
        try
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
        String sql = "SELECT Location FROM screen WHERE Movie_iD = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1,this.movieID);
        ResultSet rs = pst.executeQuery();
        
        setMinimumSize(new Dimension(400, 300));

        // Fetch movie count from the database
        int movieCount = getMovieCount();
        if (movieCount == 0) {
            // Handle the case where there are no movies
            return;
        }
        
        cityDropdown = new JComboBox<>();
        cityDropdown.addItem("NULL");
        if (rs.next()) {
        while(rs.next())
        {
        cityDropdown.addItem(rs.getString(1));
        }
        }
        
        screenDropdown = new JComboBox<>();
        screenDropdown.addItem("NULL");
        int ide = movieID;
        cityDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to be executed when the selected item changes
                screenDropdown.removeAllItems();
                screenDropdown.addItem("NULL");
                String selectedOption = (String) cityDropdown.getSelectedItem();
                System.out.println("Selected option: " + selectedOption);
                
                try
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
                 String sql1 = "SELECT Screen_iD FROM screen WHERE Movie_iD = ? AND Location = ?";
                 PreparedStatement pst1 = con.prepareStatement(sql1);
                 pst1.setInt(1,ide);
                 pst1.setString(2,selectedOption);
                 ResultSet rs1 = pst1.executeQuery();
                 System.out.println("Selected option: " + selectedOption);
                 
        while(rs1.next())          
        {
        System.out.println("Selected option: " + rs1.getString(1));
        screenDropdown.addItem(rs1.getString(1));
        }
        
        }
                catch (Exception f)
        {
            f.printStackTrace(); // Print the stack trace for debugging
            JOptionPane.showMessageDialog(null, "Error!");
        }
            }
        });
        
        
        // Fetch total seats for the first movie (you can modify this based on your logic)
        totalSeats = 60; // getTotalSeatsForMovie(27); // Assuming Movie_iD starts from 1
        
        // Create a dropdown list with seat numbers
        dateDropdown = new JComboBox<>();
        dateDropdown.addItem("NULL");
        screenDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to be executed when the selected item changes
                dateDropdown.removeAllItems();
                dateDropdown.addItem("NULL");
                String selectedOption = (String) screenDropdown.getSelectedItem();
                String selectedOption2 = (String) cityDropdown.getSelectedItem();
                System.out.println("Selected option: " + selectedOption);
                
                try
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
                 String sql1 = "SELECT Date FROM screen WHERE Movie_iD = ? AND Location = ? And Screen_iD = ?";
                 PreparedStatement pst1 = con.prepareStatement(sql1);
                 pst1.setInt(1,ide);
                 pst1.setString(2,selectedOption2);
                 pst1.setString(3,selectedOption);
                 ResultSet rs1 = pst1.executeQuery();
                 while(rs1.next())
        {
        dateDropdown.addItem(rs1.getString(1));
        }
        }
                catch (Exception f)
        {
            f.printStackTrace(); // Print the stack trace for debugging
            JOptionPane.showMessageDialog(null, "Error!");
        }
            }
        });
        
        timeDropdown = new JComboBox<>();
        timeDropdown.addItem("NULL");
        dateDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to be executed when the selected item changes
                timeDropdown.removeAllItems();
                timeDropdown.addItem("NULL");
                String selectedOption = (String) screenDropdown.getSelectedItem();
                String selectedOption2 = (String) cityDropdown.getSelectedItem();
                String selectedOption3 = (String) dateDropdown.getSelectedItem();
                System.out.println("Selected option: " + selectedOption);
                
                try
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
                 String sql1 = "SELECT Time FROM screen WHERE Movie_iD = ? AND Location = ? And Screen_iD = ? And Date = ?";
                 PreparedStatement pst1 = con.prepareStatement(sql1);
                 pst1.setInt(1,ide);
                 pst1.setString(2,selectedOption2);
                 pst1.setString(3,selectedOption);
                 pst1.setString(4,selectedOption3);
                 ResultSet rs1 = pst1.executeQuery();
                 while(rs1.next())
        {
        timeDropdown.addItem(rs1.getString(1));
        }
        }
                catch (Exception f)
        {
            f.printStackTrace(); // Print the stack trace for debugging
            JOptionPane.showMessageDialog(null, "Error!");
        }
            }
        });
        
        seatDropdown = new JComboBox<>();
        seatDropdown.addItem("NULL");
        timeDropdown.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to be executed when the selected item changes
                seatDropdown.removeAllItems();
                for (int i = 1; i <= 60; i++) {
                seatDropdown.addItem( Integer.toString(i));
                }
                seatDropdown.addItem("NULL");
                String selectedOption = (String) screenDropdown.getSelectedItem();
                String selectedOption2 = (String) cityDropdown.getSelectedItem();
                String selectedOption3 = (String) dateDropdown.getSelectedItem();
                String selectedOption4 = (String) timeDropdown.getSelectedItem();
                System.out.println("Selected option: " + selectedOption);
                
                try
        {
         Class.forName("com.mysql.cj.jdbc.Driver");
            
                    
            String url = "jdbc:mysql://localhost:3306/seatselect";
            String user = "root";
            String pass = "";
            
            Connection con = DriverManager.getConnection(url,user,pass);
                 String sql1 = "SELECT `seat_number` FROM reservations Join screen on screen.Show_iD = reservations.Show_iD WHERE Movie_iD = ? AND Location = ? And Screen_iD = ? And Date = ? And Time = ?";
                 PreparedStatement pst1 = con.prepareStatement(sql1);
                 pst1.setInt(1,ide);
                 pst1.setString(2,selectedOption2);
                 pst1.setString(3,selectedOption);
                 pst1.setString(4,selectedOption3);
                 pst1.setString(5,selectedOption4);
                 ResultSet rs1 = pst1.executeQuery();
                 while(rs1.next())
        {
        seatDropdown.removeItem(rs1.getString(1));
        }
        }
                catch (Exception f)
        {
            f.printStackTrace(); // Print the stack trace for debugging
            JOptionPane.showMessageDialog(null, "Error!");
        }
            }
        });
        // Dropdown for selecting screens (1 to 5)
        

        // Dropdown for selecting cities


        JPanel seatPanel = new JPanel();
        seatPanel.setBackground(Color.CYAN);
        seatPanel.add(new JLabel("Select City:"));
        seatPanel.add(cityDropdown);
        seatPanel.add(new JLabel("Select Screen:"));
        seatPanel.add(screenDropdown);
        seatPanel.add(new JLabel("Select Date:"));
        seatPanel.add(dateDropdown);
        seatPanel.add(new JLabel("Select Time:"));
        seatPanel.add(timeDropdown);
        seatPanel.add(new JLabel("Select Seats:"));
        seatPanel.add(seatDropdown);

        JButton proceedButton = new JButton("Proceed");
        proceedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle the "Proceed" button click
                handleProceedButtonClick();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.CYAN);
        buttonPanel.add(proceedButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(seatPanel, BorderLayout.CENTER);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        pack();

        JPanel permanentLabelsPanel = new JPanel(new GridLayout(1, 3));
        permanentLabelsPanel.setBackground(Color.CYAN);

        // Create labels for seat categories
        JLabel silverLabel = new JLabel("1-20   Silver");
        JLabel goldLabel = new JLabel("21-40  Gold");
        JLabel premiumLabel = new JLabel("41-60  Premium");

        // Add labels to the panel
        permanentLabelsPanel.add(silverLabel);
        permanentLabelsPanel.add(goldLabel);
        permanentLabelsPanel.add(premiumLabel);

        // Set the preferred size to make it square (adjust the values as needed)
        Dimension preferredSize = new Dimension(375, 30); // Adjust the height as needed
        permanentLabelsPanel.setPreferredSize(preferredSize);

        // Create a panel for labels and "Proceed" button
        JPanel bottomLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomLeftPanel.add(permanentLabelsPanel);

        // Add the panel to the bottom left of the main frame
        getContentPane().add(bottomLeftPanel, BorderLayout.BEFORE_FIRST_LINE);
        }
        catch (Exception e)
        {
            e.printStackTrace(); // Print the stack trace for debugging
            JOptionPane.showMessageDialog(null, "Error!");
        }
        
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0));
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(java.awt.Color.cyan);

        jPanel2.setBackground(java.awt.Color.black);
        jPanel2.setForeground(java.awt.Color.cyan);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(java.awt.Color.cyan);
        jLabel1.setText("Seat Selection");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(173, 173, 173))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(11, Short.MAX_VALUE))
        );

        jPanel3.setBackground(java.awt.Color.cyan);
        jPanel3.setPreferredSize(new java.awt.Dimension(75, 23));
        java.awt.GridBagLayout jPanel3Layout = new java.awt.GridBagLayout();
        jPanel3Layout.columnWidths = new int[] {0, 5, 0, 5, 0, 5, 0, 5, 0, 5, 0, 5, 0, 5, 0};
        jPanel3Layout.rowHeights = new int[] {0, 5, 0, 5, 0, 5, 0, 5, 0, 5, 0};
        jPanel3.setLayout(jPanel3Layout);

        jButton4.setText("18");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 6;
        jPanel3.add(jButton4, gridBagConstraints);

        jButton5.setText("12");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        jPanel3.add(jButton5, gridBagConstraints);

        jButton6.setText("2 ");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        jPanel3.add(jButton6, gridBagConstraints);

        jButton7.setText("20");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 6;
        jPanel3.add(jButton7, gridBagConstraints);

        jButton8.setText("15");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 4;
        jPanel3.add(jButton8, gridBagConstraints);

        jButton9.setText("8 ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        jPanel3.add(jButton9, gridBagConstraints);

        jButton10.setText("11");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        jPanel3.add(jButton10, gridBagConstraints);

        jButton11.setText("19");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 6;
        jPanel3.add(jButton11, gridBagConstraints);

        jButton12.setText("13");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        jPanel3.add(jButton12, gridBagConstraints);

        jButton13.setText("16");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        jPanel3.add(jButton13, gridBagConstraints);

        jButton14.setText("1");
        jButton14.setMinimumSize(new java.awt.Dimension(75, 23));
        jButton14.setPreferredSize(new java.awt.Dimension(75, 23));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        jPanel3.add(jButton14, gridBagConstraints);
        jButton14.getAccessibleContext().setAccessibleDescription("");

        jButton15.setText("6 ");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        jPanel3.add(jButton15, gridBagConstraints);

        jButton16.setText("3 ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        jPanel3.add(jButton16, gridBagConstraints);

        jButton17.setText("10");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 2;
        jPanel3.add(jButton17, gridBagConstraints);

        jButton18.setText("7 ");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        jPanel3.add(jButton18, gridBagConstraints);

        jButton19.setText("14");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 4;
        jPanel3.add(jButton19, gridBagConstraints);

        jButton20.setText("9 ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 2;
        jPanel3.add(jButton20, gridBagConstraints);

        jButton21.setText("17");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        jPanel3.add(jButton21, gridBagConstraints);

        jButton22.setText("22");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 8;
        jPanel3.add(jButton22, gridBagConstraints);

        jButton23.setText("21");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        jPanel3.add(jButton23, gridBagConstraints);

        jButton24.setText("4 ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        jPanel3.add(jButton24, gridBagConstraints);

        jButton25.setText("5 ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 0;
        jPanel3.add(jButton25, gridBagConstraints);

        jButton26.setText("15");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 4;
        jPanel3.add(jButton26, gridBagConstraints);

        jButton29.setText("jButton4");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 6;
        jPanel3.add(jButton29, gridBagConstraints);

        jButton31.setText("25");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 8;
        jPanel3.add(jButton31, gridBagConstraints);

        jButton30.setText("24");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 8;
        jPanel3.add(jButton30, gridBagConstraints);

        jButton32.setText("23 ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 8;
        jPanel3.add(jButton32, gridBagConstraints);

        jButton1.setBackground(java.awt.Color.red);
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Booked");

        jButton2.setBackground(java.awt.Color.yellow);
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setText("Selected");

        jButton3.setBackground(java.awt.Color.green);
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton3.setText("Availaible");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel5.setBackground(java.awt.Color.black);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Seats Selected:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("XYZ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(9, Short.MAX_VALUE)
                                .addComponent(jLabel2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)))
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(4, 4, 4)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)
                        .addGap(32, 32, 32))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton23ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler filler1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    // End of variables declaration//GEN-END:variables
}
